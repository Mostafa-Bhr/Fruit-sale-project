const applejusice=Fruit(prompt("enter fruit"),prompt("enter fruit"))


function Fruit(apple,orange){

const jusice= `jusice ${apple} apple and ${orange} orange`
return jusice    
}
console.log(applejusice);




